# GitHub Pages
Carica questi file in un repository e abilita GitHub Pages.
Sostituisci i file nella cartella media e modifica l'array items in script.js.
